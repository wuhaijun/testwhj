module.exports = {
     "server": "https://ireader.brainboom.cn",
      "app": {
        "appId": "wxc8f0fa60acaa416d",
        "appSecret": "appSecret",
        "appName": "脑洞阅读"
      },
      "qiniu": {
        "imageHost": "http://boom-static.static.cceato.com/"
      },
      "image": {
        "qrImage": "https://ireader.brainboom.cn/public/img/mpqr.png"
      },
    }