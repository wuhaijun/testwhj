import Taro, { Component } from '@tarojs/taro'
import './template.less'

class HtmlTemplate extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (<View>xxx</View>)
    }
}

export default HtmlTemplate
